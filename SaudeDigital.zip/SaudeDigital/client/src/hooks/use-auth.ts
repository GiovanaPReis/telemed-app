import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  username: string;
  role: 'secretary' | 'patient';
}

interface Patient {
  id: string;
  name: string;
  cpf: string;
  phone?: string;
  email?: string;
  birthDate?: string;
}

interface AuthState {
  user: User | null;
  patient: Patient | null;
  isAuthenticated: boolean;
  login: (user: User, patient?: Patient) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      patient: null,
      isAuthenticated: false,
      login: (user: User, patient?: Patient) => {
        set({ user, patient, isAuthenticated: true });
      },
      logout: () => {
        set({ user: null, patient: null, isAuthenticated: false });
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);
