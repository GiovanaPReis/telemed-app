import { ReactNode } from "react";

interface MobileLayoutProps {
  children: ReactNode;
  showTabBar?: boolean;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function MobileLayout({ children, showTabBar = false, activeTab, onTabChange }: MobileLayoutProps) {
  return (
    <div className="mobile-container">
      <div className={showTabBar ? "pb-16" : ""}>{children}</div>
      
      {showTabBar && (
        <div className="tab-bar">
          <div className="flex">
            <button 
              onClick={() => onTabChange?.('dashboard')}
              className={`flex-1 py-3 text-center ${activeTab === 'dashboard' ? 'bg-primary-blue text-white' : 'text-gray-600'}`}
            >
              <div className="text-xs">Dashboard</div>
            </button>
            <button 
              onClick={() => onTabChange?.('patients')}
              className={`flex-1 py-3 text-center ${activeTab === 'patients' ? 'bg-primary-blue text-white' : 'text-gray-600'}`}
            >
              <div className="text-xs">Pacientes</div>
            </button>
            <button 
              onClick={() => onTabChange?.('calendar')}
              className={`flex-1 py-3 text-center ${activeTab === 'calendar' ? 'bg-primary-blue text-white' : 'text-gray-600'}`}
            >
              <div className="text-xs">Agenda</div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
