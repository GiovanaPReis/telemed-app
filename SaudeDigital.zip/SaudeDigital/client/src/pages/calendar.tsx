import { useLocation } from "wouter";
import { Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { MobileLayout } from "@/components/mobile-layout";

export default function Calendar() {
  const [, setLocation] = useLocation();

  const today = new Date().toISOString().split('T')[0];
  const { data: todayAppointments = [] } = useQuery({
    queryKey: ["/api/appointments"],
    queryFn: async () => {
      const response = await fetch(`/api/appointments?date=${today}`);
      return response.json();
    },
  });

  const { data: patients = [] } = useQuery({
    queryKey: ["/api/patients"],
  });

  const handleTabChange = (tab: string) => {
    switch (tab) {
      case 'dashboard':
        setLocation("/secretary/dashboard");
        break;
      case 'patients':
        setLocation("/secretary/patients");
        break;
      default:
        break;
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  const generateCalendarDays = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days = [];
    const currentDateString = currentDate.toISOString().split('T')[0];
    
    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      
      const isCurrentMonth = date.getMonth() === month;
      const isToday = date.toISOString().split('T')[0] === currentDateString;
      
      days.push({
        date: date.getDate(),
        isCurrentMonth,
        isToday,
        dateString: date.toISOString().split('T')[0],
      });
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();

  return (
    <MobileLayout showTabBar activeTab="calendar" onTabChange={handleTabChange}>
      <div className="min-h-screen bg-light-gray">
        <div className="bg-primary-blue text-white p-6">
          <div className="flex items-center justify-between">
            <h1 className="text-lg font-semibold">Agenda</h1>
            <button className="text-white">
              <Plus className="w-6 h-6" />
            </button>
          </div>
          <p className="text-blue-100 mt-2">{formatDate(new Date())}</p>
        </div>

        <div className="p-4">
          {/* Calendar Grid */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <div className="grid grid-cols-7 gap-1 mb-2">
              {['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'].map((day) => (
                <div key={day} className="text-center text-xs font-medium text-gray-600 py-2">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((day, index) => (
                <div
                  key={index}
                  className={`text-center py-2 text-sm ${
                    !day.isCurrentMonth
                      ? 'text-gray-400'
                      : day.isToday
                      ? 'bg-primary-blue text-white rounded'
                      : ''
                  }`}
                >
                  {day.date}
                </div>
              ))}
            </div>
          </div>

          {/* Today's Appointments */}
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h3 className="font-semibold text-dark-gray mb-3">
              Agendamentos de Hoje ({new Date().toLocaleDateString('pt-BR')})
            </h3>
            {todayAppointments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Nenhum agendamento para hoje</p>
            ) : (
              <div className="space-y-3">
                {todayAppointments.map((appointment: any) => {
                  const patient = patients.find((p: any) => p.id === appointment.patientId);
                  const statusColors = {
                    scheduled: 'border-primary-blue bg-blue-50',
                    in_progress: 'border-orange-500 bg-orange-50',
                    completed: 'border-success-green bg-green-50',
                    cancelled: 'border-red-500 bg-red-50',
                  };
                  
                  const statusLabels = {
                    scheduled: 'Agendado',
                    in_progress: 'Em andamento',
                    completed: 'Concluído',
                    cancelled: 'Cancelado',
                  };

                  return (
                    <div 
                      key={appointment.id} 
                      className={`border-l-4 p-3 rounded-r-lg ${statusColors[appointment.status as keyof typeof statusColors] || statusColors.scheduled}`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-medium text-dark-gray">{appointment.time}</div>
                          <div className="text-sm text-gray-600">
                            {patient?.name || "Paciente não encontrado"}
                          </div>
                          <div className="text-xs text-gray-500">{appointment.type}</div>
                        </div>
                        <div className="text-xs bg-white px-2 py-1 rounded border">
                          {statusLabels[appointment.status as keyof typeof statusLabels] || 'Agendado'}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
