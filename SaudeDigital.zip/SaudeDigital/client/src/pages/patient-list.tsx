import { useState } from "react";
import { useLocation } from "wouter";
import { Plus, Search, Edit, Trash } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MobileLayout } from "@/components/mobile-layout";

export default function PatientList() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: patients = [], isLoading } = useQuery({
    queryKey: ["/api/patients"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (patientId: string) => {
      const response = await apiRequest("DELETE", `/api/patients/${patientId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/patients"] });
      toast({
        title: "Paciente removido",
        description: "Paciente foi removido com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível remover o paciente",
        variant: "destructive",
      });
    },
  });

  const filteredPatients = patients.filter((patient: any) =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.cpf.includes(searchTerm)
  );

  const handleTabChange = (tab: string) => {
    switch (tab) {
      case 'dashboard':
        setLocation("/secretary/dashboard");
        break;
      case 'calendar':
        setLocation("/secretary/calendar");
        break;
      default:
        break;
    }
  };

  const handleDelete = (patientId: string) => {
    if (confirm("Tem certeza que deseja remover este paciente?")) {
      deleteMutation.mutate(patientId);
    }
  };

  return (
    <MobileLayout showTabBar activeTab="patients" onTabChange={handleTabChange}>
      <div className="min-h-screen bg-light-gray">
        <div className="bg-primary-blue text-white p-6">
          <div className="flex items-center justify-between">
            <h1 className="text-lg font-semibold">Lista de Pacientes</h1>
            <button onClick={() => setLocation("/secretary/add-patient")} className="text-white">
              <Plus className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-4">
          {/* Search */}
          <div className="mb-4 relative">
            <Search className="w-5 h-5 absolute left-3 top-3 text-gray-400" />
            <input 
              type="text" 
              placeholder="Buscar paciente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 p-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
            />
          </div>

          {/* Patient List */}
          {isLoading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-4 border-primary-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-gray-600">Carregando pacientes...</p>
            </div>
          ) : filteredPatients.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600">Nenhum paciente encontrado</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredPatients.map((patient: any) => (
                <div key={patient.id} className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-dark-gray">{patient.name}</div>
                      <div className="text-sm text-gray-600">CPF: {patient.cpf}</div>
                      {patient.phone && (
                        <div className="text-sm text-gray-600">Tel: {patient.phone}</div>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      <button className="bg-primary-blue text-white p-2 rounded text-xs">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(patient.id)}
                        disabled={deleteMutation.isPending}
                        className="bg-red-500 text-white p-2 rounded text-xs disabled:opacity-50"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
