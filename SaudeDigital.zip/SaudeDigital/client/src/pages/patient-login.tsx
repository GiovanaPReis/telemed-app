import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { MobileLayout } from "@/components/mobile-layout";

export default function PatientLogin() {
  const [, setLocation] = useLocation();
  const [cpf, setCpf] = useState("");
  const [password, setPassword] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [newPatientData, setNewPatientData] = useState({
    name: "",
    phone: "",
    email: "",
    birthDate: "",
  });
  const { login } = useAuth();
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (credentials: { username: string; password: string; role: string }) => {
      const response = await apiRequest("POST", "/api/auth/login", credentials);
      return response.json();
    },
    onSuccess: (data) => {
      login(data.user, data.patient);
      setLocation("/patient/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Erro no login",
        description: "CPF ou senha inválidos",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/auth/register-patient", data);
      return response.json();
    },
    onSuccess: (data) => {
      login(data.user, data.patient);
      setLocation("/patient/dashboard");
      toast({
        title: "Conta criada com sucesso",
        description: "Bem-vindo ao sistema!",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar conta",
        description: "Verifique os dados e tente novamente",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreating) {
      registerMutation.mutate({
        cpf,
        password,
        ...newPatientData,
      });
    } else {
      loginMutation.mutate({
        username: cpf,
        password,
        role: "patient",
      });
    }
  };

  const formatCpf = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        <div className="p-6 pt-12">
          <button onClick={() => setLocation("/login")} className="mb-8 text-primary-blue">
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-dark-gray mb-2">
              {isCreating ? "Criar Conta" : "Login Paciente"}
            </h2>
            <p className="text-gray-600">
              {isCreating ? "Preencha seus dados" : "Digite seu CPF e senha"}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 mb-6">
            {isCreating && (
              <div>
                <label className="block text-sm font-medium text-dark-gray mb-2">Nome completo</label>
                <input 
                  type="text" 
                  value={newPatientData.name}
                  onChange={(e) => setNewPatientData({...newPatientData, name: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                  placeholder="Digite seu nome completo"
                  required
                />
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">CPF</label>
              <input 
                type="text" 
                value={cpf}
                onChange={(e) => setCpf(formatCpf(e.target.value))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="000.000.000-00"
                maxLength={14}
                required
              />
            </div>
            
            {isCreating && (
              <>
                <div>
                  <label className="block text-sm font-medium text-dark-gray mb-2">Telefone</label>
                  <input 
                    type="tel" 
                    value={newPatientData.phone}
                    onChange={(e) => setNewPatientData({...newPatientData, phone: e.target.value})}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                    placeholder="(11) 99999-9999"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-gray mb-2">E-mail</label>
                  <input 
                    type="email" 
                    value={newPatientData.email}
                    onChange={(e) => setNewPatientData({...newPatientData, email: e.target.value})}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                    placeholder="email@exemplo.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-gray mb-2">Data de nascimento</label>
                  <input 
                    type="date" 
                    value={newPatientData.birthDate}
                    onChange={(e) => setNewPatientData({...newPatientData, birthDate: e.target.value})}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                  />
                </div>
              </>
            )}
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Senha</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="••••••••"
                required
              />
            </div>

            <button 
              type="submit"
              disabled={loginMutation.isPending || registerMutation.isPending}
              className="w-full bg-success-green text-white py-3 rounded-lg text-base font-medium hover:bg-green-600 transition-colors disabled:opacity-50"
            >
              {loginMutation.isPending || registerMutation.isPending ? "Processando..." : 
               isCreating ? "Criar Conta" : "Entrar"}
            </button>
          </form>

          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">
              {isCreating ? "Já tem uma conta?" : "Primeira vez aqui?"}
            </p>
            <button 
              onClick={() => setIsCreating(!isCreating)}
              className="text-primary-blue text-sm font-medium"
            >
              {isCreating ? "Fazer login" : "Criar conta"}
            </button>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
