import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MobileLayout } from "@/components/mobile-layout";

export default function AddPatient() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: "",
    cpf: "",
    phone: "",
    email: "",
    birthDate: "",
  });

  const createPatientMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/patients", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/patients"] });
      toast({
        title: "Paciente criado",
        description: "Paciente foi adicionado com sucesso",
      });
      setLocation("/secretary/patients");
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar o paciente",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createPatientMutation.mutate(formData);
  };

  const formatCpf = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value;
    
    if (field === 'cpf') {
      formattedValue = formatCpf(value);
    } else if (field === 'phone') {
      formattedValue = formatPhone(value);
    }
    
    setFormData(prev => ({
      ...prev,
      [field]: formattedValue
    }));
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        <div className="p-6 pt-12">
          <button onClick={() => setLocation("/secretary/patients")} className="mb-8 text-primary-blue">
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-dark-gray mb-2">Novo Paciente</h2>
            <p className="text-gray-600">Preencha os dados do paciente</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Nome completo</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="Digite o nome completo"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">CPF</label>
              <input 
                type="text" 
                value={formData.cpf}
                onChange={(e) => handleInputChange('cpf', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="000.000.000-00"
                maxLength={14}
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Telefone</label>
              <input 
                type="tel" 
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="(11) 99999-9999"
                maxLength={15}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">E-mail</label>
              <input 
                type="email" 
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="email@exemplo.com"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Data de nascimento</label>
              <input 
                type="date" 
                value={formData.birthDate}
                onChange={(e) => handleInputChange('birthDate', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
              />
            </div>

            <div className="mt-8 space-y-3">
              <button 
                type="submit"
                disabled={createPatientMutation.isPending}
                className="w-full bg-primary-blue text-white py-3 rounded-lg text-base font-medium hover:bg-blue-600 transition-colors disabled:opacity-50"
              >
                {createPatientMutation.isPending ? "Salvando..." : "Salvar Paciente"}
              </button>
              <button 
                type="button"
                onClick={() => setLocation("/secretary/patients")}
                className="w-full bg-gray-300 text-dark-gray py-3 rounded-lg text-base font-medium hover:bg-gray-400 transition-colors"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      </div>
    </MobileLayout>
  );
}
