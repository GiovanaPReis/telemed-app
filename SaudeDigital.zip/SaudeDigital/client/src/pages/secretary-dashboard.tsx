import { useLocation } from "wouter";
import { LogOut, Clipboard, Calendar, Users, Play, Pause, Square } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { MobileLayout } from "@/components/mobile-layout";

export default function SecretaryDashboard() {
  const [, setLocation] = useLocation();
  const { logout } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const today = new Date().toISOString().split('T')[0];
  const { data: todayAppointments = [] } = useQuery({
    queryKey: ["/api/appointments"],
    queryFn: async () => {
      const response = await fetch(`/api/appointments?date=${today}`);
      return response.json();
    },
  });

  const { data: patients = [] } = useQuery({
    queryKey: ["/api/patients"],
  });

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const handleTabChange = (tab: string) => {
    switch (tab) {
      case 'patients':
        setLocation("/secretary/patients");
        break;
      case 'calendar':
        setLocation("/secretary/calendar");
        break;
      default:
        break;
    }
  };

  return (
    <MobileLayout showTabBar activeTab="dashboard" onTabChange={handleTabChange}>
      <div className="min-h-screen bg-light-gray">
        {/* Header */}
        <div className="bg-primary-blue text-white p-6 pb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-lg font-semibold">Dashboard Secretária</h1>
            <button onClick={handleLogout} className="text-white">
              <LogOut className="w-6 h-6" />
            </button>
          </div>
          <p className="text-blue-100">Olá, Maria! Bem-vinda de volta.</p>
        </div>

        <div className="p-4 -mt-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-2xl font-semibold text-primary-blue">
                {stats?.todayPatients || 0}
              </div>
              <div className="text-xs text-gray-600">Pacientes hoje</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-2xl font-semibold text-orange-500">
                {stats?.cancellations || 0}
              </div>
              <div className="text-xs text-gray-600">Desmarcações</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-2xl font-semibold text-success-green">
                {stats?.avgWaitTime || 0}min
              </div>
              <div className="text-xs text-gray-600">Tempo médio</div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <button 
              onClick={() => setLocation("/secretary/patients")}
              className="bg-white p-4 rounded-lg shadow-sm text-left hover:bg-gray-50 transition-colors"
            >
              <div className="w-8 h-8 bg-primary-blue rounded-full flex items-center justify-center mb-2">
                <Clipboard className="w-4 h-4 text-white" />
              </div>
              <div className="text-sm font-medium text-dark-gray">Lista de Pacientes</div>
            </button>
            <button 
              onClick={() => setLocation("/secretary/calendar")}
              className="bg-white p-4 rounded-lg shadow-sm text-left hover:bg-gray-50 transition-colors"
            >
              <div className="w-8 h-8 bg-success-green rounded-full flex items-center justify-center mb-2">
                <Calendar className="w-4 h-4 text-white" />
              </div>
              <div className="text-sm font-medium text-dark-gray">Calendário</div>
            </button>
          </div>

          {/* Today's Patients */}
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h3 className="font-semibold text-dark-gray mb-3">Pacientes de Hoje</h3>
            {todayAppointments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Nenhum agendamento para hoje</p>
            ) : (
              <div className="space-y-3">
                {todayAppointments.map((appointment: any) => {
                  const patient = patients.find((p: any) => p.id === appointment.patientId);
                  return (
                    <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-dark-gray">
                          {patient?.name || "Paciente não encontrado"}
                        </div>
                        <div className="text-sm text-gray-600">
                          {appointment.time} - {appointment.type}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="bg-success-green text-white px-3 py-1 rounded text-xs">
                          <Play className="w-3 h-3" />
                        </button>
                        <button className="bg-orange-500 text-white px-3 py-1 rounded text-xs">
                          <Pause className="w-3 h-3" />
                        </button>
                        <button className="bg-red-500 text-white px-3 py-1 rounded text-xs">
                          <Square className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
