import { useLocation } from "wouter";
import { LogOut, Heart } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { MobileLayout } from "@/components/mobile-layout";

export default function PatientDashboard() {
  const [, setLocation] = useLocation();
  const { logout, patient } = useAuth();

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const handleCheckin = () => {
    setLocation("/patient/waiting");
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <div className="bg-success-green text-white p-6 pb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-lg font-semibold">Área do Paciente</h1>
            <button onClick={handleLogout} className="text-white">
              <LogOut className="w-6 h-6" />
            </button>
          </div>
          <p className="text-green-100">
            Olá, {patient?.name || "Paciente"}! Como você está hoje?
          </p>
        </div>

        <div className="p-6 -mt-4">
          {/* Welcome Message */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6 text-center">
            <div className="w-16 h-16 bg-success-green rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-dark-gray mb-2">
              Hora de dar um check na sua saúde
            </h2>
            <p className="text-gray-600 mb-6">
              Toque no botão abaixo para fazer seu check-in e entrar na fila de atendimento.
            </p>
            <button 
              onClick={handleCheckin}
              className="w-full bg-success-green text-white py-4 rounded-lg text-base font-medium hover:bg-green-600 transition-colors"
            >
              Fazer Check-in
            </button>
          </div>

          {/* Next Appointment */}
          <div className="bg-secondary-blue rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-dark-gray mb-2">Próxima Consulta</h3>
            <div className="text-sm text-gray-600">
              <div>Hoje, 14:30</div>
              <div>Dr. Carlos Silva - Cardiologia</div>
            </div>
          </div>

          {/* Quick Info */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-dark-gray mb-3">Informações</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">CPF:</span>
                <span className="text-dark-gray">{patient?.cpf}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Telefone:</span>
                <span className="text-dark-gray">{patient?.phone || "Não informado"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">E-mail:</span>
                <span className="text-dark-gray">{patient?.email || "Não informado"}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
