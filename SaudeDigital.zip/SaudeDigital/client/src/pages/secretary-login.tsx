import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { MobileLayout } from "@/components/mobile-layout";

export default function SecretaryLogin() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (credentials: { username: string; password: string; role: string }) => {
      const response = await apiRequest("POST", "/api/auth/login", credentials);
      return response.json();
    },
    onSuccess: (data) => {
      login(data.user);
      setLocation("/secretary/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Erro no login",
        description: "Credenciais inválidas",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({
      username: email,
      password,
      role: "secretary",
    });
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        <div className="p-6 pt-12">
          <button onClick={() => setLocation("/login")} className="mb-8 text-primary-blue">
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-dark-gray mb-2">Login Secretária</h2>
            <p className="text-gray-600">Digite suas credenciais</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Email</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="secretaria@clinica.com.br"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-gray mb-2">Senha</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-blue"
                placeholder="••••••••"
                required
              />
            </div>

            <button 
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full bg-primary-blue text-white py-3 rounded-lg text-base font-medium hover:bg-blue-600 transition-colors disabled:opacity-50"
            >
              {loginMutation.isPending ? "Entrando..." : "Entrar"}
            </button>
          </form>
        </div>
      </div>
    </MobileLayout>
  );
}
