import { useLocation } from "wouter";
import { ArrowLeft, User, Heart } from "lucide-react";
import { MobileLayout } from "@/components/mobile-layout";

export default function LoginSelection() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        <div className="p-6 pt-12">
          <button onClick={() => setLocation("/")} className="mb-8 text-primary-blue">
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-dark-gray mb-2">Login</h2>
            <p className="text-gray-600">Escolha seu tipo de acesso</p>
          </div>

          <div className="space-y-4 mb-8">
            <button 
              onClick={() => setLocation("/login/secretary")}
              className="w-full p-4 border border-gray-200 rounded-lg text-left hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <div className="w-10 h-10 bg-primary-blue rounded-full flex items-center justify-center mr-3">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-medium text-dark-gray">Secretária</h3>
                  <p className="text-sm text-gray-600">Gerenciar agendamentos e pacientes</p>
                </div>
              </div>
            </button>

            <button 
              onClick={() => setLocation("/login/patient")}
              className="w-full p-4 border border-gray-200 rounded-lg text-left hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <div className="w-10 h-10 bg-success-green rounded-full flex items-center justify-center mr-3">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-medium text-dark-gray">Paciente</h3>
                  <p className="text-sm text-gray-600">Fazer check-in e acompanhar consulta</p>
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
