import { useLocation } from "wouter";
import { Clock } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { MobileLayout } from "@/components/mobile-layout";
import { useEffect } from "react";

export default function WaitingRoom() {
  const [, setLocation] = useLocation();
  const { patient } = useAuth();
  const { toast } = useToast();

  // Check if patient is already in queue
  const { data: queueEntry, isLoading } = useQuery({
    queryKey: ["/api/queue/patient", patient?.id],
    enabled: !!patient?.id,
  });

  // Add to queue mutation
  const checkinMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/queue/checkin", {
        patientId: patient?.id,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue/patient", patient?.id] });
      toast({
        title: "Check-in realizado",
        description: "Você foi adicionado à fila de atendimento",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro no check-in",
        description: "Não foi possível fazer o check-in",
        variant: "destructive",
      });
    },
  });

  // Remove from queue mutation
  const cancelMutation = useMutation({
    mutationFn: async () => {
      if (queueEntry?.id) {
        const response = await apiRequest("DELETE", `/api/queue/${queueEntry.id}`);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue/patient", patient?.id] });
      setLocation("/patient/dashboard");
      toast({
        title: "Check-in cancelado",
        description: "Você foi removido da fila de atendimento",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Não foi possível cancelar o atendimento",
        variant: "destructive",
      });
    },
  });

  // Auto check-in if not in queue
  useEffect(() => {
    if (!isLoading && !queueEntry && patient?.id) {
      checkinMutation.mutate();
    }
  }, [isLoading, queueEntry, patient?.id]);

  const handleCancel = () => {
    cancelMutation.mutate();
  };

  if (isLoading || checkinMutation.isPending) {
    return (
      <MobileLayout>
        <div className="min-h-screen bg-white flex items-center justify-center">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-primary-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Fazendo check-in...</p>
          </div>
        </div>
      </MobileLayout>
    );
  }

  if (!queueEntry) {
    return (
      <MobileLayout>
        <div className="min-h-screen bg-white flex items-center justify-center">
          <div className="text-center p-6">
            <p className="text-gray-600 mb-4">Não foi possível acessar a fila</p>
            <button 
              onClick={() => setLocation("/patient/dashboard")}
              className="bg-primary-blue text-white px-4 py-2 rounded-lg"
            >
              Voltar
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white">
        <div className="p-6 pt-12">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-success-green rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-dark-gray mb-2">
              Você está na fila!
            </h2>
            <p className="text-gray-600">
              Aguarde ser chamado para sua consulta
            </p>
          </div>

          {/* Queue Status */}
          <div className="bg-light-gray rounded-lg p-6 mb-6 text-center">
            <div className="text-3xl font-bold text-primary-blue mb-2">
              {queueEntry.position}º
            </div>
            <div className="text-sm text-gray-600 mb-4">Sua posição na fila</div>
            
            <div className="text-lg font-semibold text-dark-gray mb-1">
              ~{queueEntry.estimatedWaitTime} minutos
            </div>
            <div className="text-sm text-gray-600">Tempo estimado de espera</div>
          </div>

          {/* Status Updates */}
          <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-dark-gray mb-3">Status</h3>
            <div className="flex items-center text-success-green mb-2">
              <div className="w-2 h-2 bg-success-green rounded-full mr-2"></div>
              <span className="text-sm">Check-in realizado com sucesso</span>
            </div>
            <div className="flex items-center text-gray-500">
              <div className="w-2 h-2 bg-gray-300 rounded-full mr-2"></div>
              <span className="text-sm">Aguardando chamada</span>
            </div>
          </div>

          {/* Action Button */}
          <button 
            onClick={handleCancel}
            disabled={cancelMutation.isPending}
            className="w-full bg-red-500 text-white py-3 rounded-lg text-base font-medium hover:bg-red-600 transition-colors disabled:opacity-50"
          >
            {cancelMutation.isPending ? "Cancelando..." : "Desistir do atendimento"}
          </button>

          <div className="text-center mt-4">
            <p className="text-xs text-gray-500">
              Você receberá uma notificação quando for sua vez
            </p>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
