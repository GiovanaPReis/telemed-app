import { useLocation } from "wouter";
import { Heart } from "lucide-react";
import { MobileLayout } from "@/components/mobile-layout";

export default function Welcome() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout>
      <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-b from-secondary-blue to-white">
        <div className="text-center mb-12">
          <div className="w-24 h-24 bg-primary-blue rounded-full flex items-center justify-center mx-auto mb-6">
            <Heart className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-2xl font-semibold text-dark-gray mb-4">
            Sua saúde na palma da mão
          </h1>
          <p className="text-gray-600 text-base">
            Acesso rápido e fácil aos seus cuidados médicos
          </p>
        </div>
        <button 
          onClick={() => setLocation("/login")}
          className="w-full bg-primary-blue text-white py-4 rounded-lg text-base font-medium hover:bg-blue-600 transition-colors"
        >
          Iniciar atendimento
        </button>
      </div>
    </MobileLayout>
  );
}
