import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Welcome from "@/pages/welcome";
import LoginSelection from "@/pages/login-selection";
import SecretaryLogin from "@/pages/secretary-login";
import PatientLogin from "@/pages/patient-login";
import SecretaryDashboard from "@/pages/secretary-dashboard";
import PatientDashboard from "@/pages/patient-dashboard";
import PatientList from "@/pages/patient-list";
import Calendar from "@/pages/calendar";
import AddPatient from "@/pages/add-patient";
import WaitingRoom from "@/pages/waiting-room";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Welcome} />
      <Route path="/login" component={LoginSelection} />
      <Route path="/login/secretary" component={SecretaryLogin} />
      <Route path="/login/patient" component={PatientLogin} />
      <Route path="/secretary/dashboard" component={SecretaryDashboard} />
      <Route path="/patient/dashboard" component={PatientDashboard} />
      <Route path="/secretary/patients" component={PatientList} />
      <Route path="/secretary/calendar" component={Calendar} />
      <Route path="/secretary/add-patient" component={AddPatient} />
      <Route path="/patient/waiting" component={WaitingRoom} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
