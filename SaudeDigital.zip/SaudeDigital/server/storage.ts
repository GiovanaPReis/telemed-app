import { 
  type User, 
  type InsertUser, 
  type Patient, 
  type InsertPatient, 
  type Appointment, 
  type InsertAppointment,
  type QueueEntry,
  type InsertQueueEntry
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Patient operations
  getPatient(id: string): Promise<Patient | undefined>;
  getPatientByCpf(cpf: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient & { userId?: string }): Promise<Patient>;
  updatePatient(id: string, patient: Partial<Patient>): Promise<Patient>;
  deletePatient(id: string): Promise<void>;
  getAllPatients(): Promise<Patient[]>;
  
  // Appointment operations
  getAppointment(id: string): Promise<Appointment | undefined>;
  getAppointmentsByPatient(patientId: string): Promise<Appointment[]>;
  getAppointmentsByDate(date: string): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointmentStatus(id: string, status: string): Promise<Appointment>;
  
  // Queue operations
  getQueueEntries(): Promise<QueueEntry[]>;
  addToQueue(entry: InsertQueueEntry): Promise<QueueEntry>;
  updateQueueStatus(id: string, status: string): Promise<QueueEntry>;
  removeFromQueue(id: string): Promise<void>;
  getPatientQueueEntry(patientId: string): Promise<QueueEntry | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private patients: Map<string, Patient>;
  private appointments: Map<string, Appointment>;
  private queueEntries: Map<string, QueueEntry>;

  constructor() {
    this.users = new Map();
    this.patients = new Map();
    this.appointments = new Map();
    this.queueEntries = new Map();
    
    // Create default secretary user
    const secretaryId = randomUUID();
    this.users.set(secretaryId, {
      id: secretaryId,
      username: "secretaria@clinica.com.br",
      password: "123456",
      role: "secretary",
      createdAt: new Date(),
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async getPatient(id: string): Promise<Patient | undefined> {
    return this.patients.get(id);
  }

  async getPatientByCpf(cpf: string): Promise<Patient | undefined> {
    return Array.from(this.patients.values()).find(
      (patient) => patient.cpf === cpf,
    );
  }

  async createPatient(patientData: InsertPatient & { userId?: string }): Promise<Patient> {
    const id = randomUUID();
    const patient: Patient = { 
      ...patientData, 
      id, 
      createdAt: new Date() 
    };
    this.patients.set(id, patient);
    return patient;
  }

  async updatePatient(id: string, patientData: Partial<Patient>): Promise<Patient> {
    const existing = this.patients.get(id);
    if (!existing) {
      throw new Error("Patient not found");
    }
    const updated = { ...existing, ...patientData };
    this.patients.set(id, updated);
    return updated;
  }

  async deletePatient(id: string): Promise<void> {
    this.patients.delete(id);
  }

  async getAllPatients(): Promise<Patient[]> {
    return Array.from(this.patients.values());
  }

  async getAppointment(id: string): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async getAppointmentsByPatient(patientId: string): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.patientId === patientId,
    );
  }

  async getAppointmentsByDate(date: string): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.date === date,
    );
  }

  async createAppointment(appointmentData: InsertAppointment): Promise<Appointment> {
    const id = randomUUID();
    const appointment: Appointment = { 
      ...appointmentData, 
      id, 
      status: "scheduled",
      createdAt: new Date() 
    };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointmentStatus(id: string, status: string): Promise<Appointment> {
    const existing = this.appointments.get(id);
    if (!existing) {
      throw new Error("Appointment not found");
    }
    const updated = { ...existing, status };
    this.appointments.set(id, updated);
    return updated;
  }

  async getQueueEntries(): Promise<QueueEntry[]> {
    return Array.from(this.queueEntries.values()).sort((a, b) => a.position - b.position);
  }

  async addToQueue(entryData: InsertQueueEntry): Promise<QueueEntry> {
    const id = randomUUID();
    const entries = await this.getQueueEntries();
    const position = entries.length + 1;
    const estimatedWaitTime = position * 15; // 15 minutes per position
    
    const queueEntry: QueueEntry = {
      ...entryData,
      id,
      status: "waiting",
      position,
      estimatedWaitTime,
      checkinTime: new Date(),
    };
    
    this.queueEntries.set(id, queueEntry);
    return queueEntry;
  }

  async updateQueueStatus(id: string, status: string): Promise<QueueEntry> {
    const existing = this.queueEntries.get(id);
    if (!existing) {
      throw new Error("Queue entry not found");
    }
    const updated = { ...existing, status };
    this.queueEntries.set(id, updated);
    return updated;
  }

  async removeFromQueue(id: string): Promise<void> {
    this.queueEntries.delete(id);
  }

  async getPatientQueueEntry(patientId: string): Promise<QueueEntry | undefined> {
    return Array.from(this.queueEntries.values()).find(
      (entry) => entry.patientId === patientId && entry.status === "waiting",
    );
  }
}

export const storage = new MemStorage();
