import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPatientSchema, insertAppointmentSchema, insertQueueEntrySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password, role } = req.body;
      
      if (role === "secretary") {
        const user = await storage.getUserByUsername(username);
        if (user && user.password === password && user.role === "secretary") {
          res.json({ user: { id: user.id, username: user.username, role: user.role } });
        } else {
          res.status(401).json({ message: "Credenciais inválidas" });
        }
      } else if (role === "patient") {
        const patient = await storage.getPatientByCpf(username);
        if (patient) {
          const user = patient.userId ? await storage.getUser(patient.userId) : null;
          if (user && user.password === password) {
            res.json({ user: { id: user.id, username: user.username, role: user.role }, patient });
          } else {
            res.status(401).json({ message: "Credenciais inválidas" });
          }
        } else {
          res.status(401).json({ message: "Paciente não encontrado" });
        }
      } else {
        res.status(400).json({ message: "Tipo de usuário inválido" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/auth/register-patient", async (req, res) => {
    try {
      const { cpf, password, ...patientData } = req.body;
      
      // Check if patient already exists
      const existingPatient = await storage.getPatientByCpf(cpf);
      if (existingPatient) {
        res.status(400).json({ message: "Paciente já cadastrado" });
        return;
      }

      // Create user account
      const user = await storage.createUser({
        username: cpf,
        password,
        role: "patient",
      });

      // Create patient record
      const patient = await storage.createPatient({
        ...patientData,
        cpf,
        userId: user.id,
      });

      res.json({ user: { id: user.id, username: user.username, role: user.role }, patient });
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar conta" });
    }
  });

  // Patient routes
  app.get("/api/patients", async (req, res) => {
    try {
      const patients = await storage.getAllPatients();
      res.json(patients);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar pacientes" });
    }
  });

  app.post("/api/patients", async (req, res) => {
    try {
      const validatedData = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(validatedData);
      res.json(patient);
    } catch (error) {
      res.status(400).json({ message: "Dados inválidos" });
    }
  });

  app.put("/api/patients/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const patient = await storage.updatePatient(id, req.body);
      res.json(patient);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar paciente" });
    }
  });

  app.delete("/api/patients/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePatient(id);
      res.json({ message: "Paciente removido com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover paciente" });
    }
  });

  // Appointment routes
  app.get("/api/appointments", async (req, res) => {
    try {
      const { date, patientId } = req.query;
      
      if (date) {
        const appointments = await storage.getAppointmentsByDate(date as string);
        res.json(appointments);
      } else if (patientId) {
        const appointments = await storage.getAppointmentsByPatient(patientId as string);
        res.json(appointments);
      } else {
        res.status(400).json({ message: "Date or patientId required" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar agendamentos" });
    }
  });

  app.post("/api/appointments", async (req, res) => {
    try {
      const validatedData = insertAppointmentSchema.parse(req.body);
      const appointment = await storage.createAppointment(validatedData);
      res.json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Dados inválidos" });
    }
  });

  app.put("/api/appointments/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const appointment = await storage.updateAppointmentStatus(id, status);
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar status do agendamento" });
    }
  });

  // Queue routes
  app.get("/api/queue", async (req, res) => {
    try {
      const queueEntries = await storage.getQueueEntries();
      res.json(queueEntries);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar fila" });
    }
  });

  app.post("/api/queue/checkin", async (req, res) => {
    try {
      const { patientId } = req.body;
      
      // Check if patient is already in queue
      const existingEntry = await storage.getPatientQueueEntry(patientId);
      if (existingEntry) {
        res.status(400).json({ message: "Paciente já está na fila" });
        return;
      }

      const queueEntry = await storage.addToQueue({ patientId, appointmentId: null });
      res.json(queueEntry);
    } catch (error) {
      res.status(500).json({ message: "Erro ao fazer check-in" });
    }
  });

  app.put("/api/queue/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const queueEntry = await storage.updateQueueStatus(id, status);
      res.json(queueEntry);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar status da fila" });
    }
  });

  app.delete("/api/queue/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.removeFromQueue(id);
      res.json({ message: "Removido da fila com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover da fila" });
    }
  });

  app.get("/api/queue/patient/:patientId", async (req, res) => {
    try {
      const { patientId } = req.params;
      const queueEntry = await storage.getPatientQueueEntry(patientId);
      res.json(queueEntry);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar posição na fila" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const todayAppointments = await storage.getAppointmentsByDate(today);
      const queueEntries = await storage.getQueueEntries();
      
      const stats = {
        todayPatients: todayAppointments.length,
        cancellations: todayAppointments.filter(a => a.status === 'cancelled').length,
        avgWaitTime: queueEntries.length > 0 ? Math.round(queueEntries.reduce((acc, entry) => acc + (entry.estimatedWaitTime || 0), 0) / queueEntries.length) : 0,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar estatísticas" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
