# Overview

This is a healthcare clinic management system built as a full-stack web application. The system provides separate interfaces for secretaries and patients, enabling appointment scheduling, patient management, and queue management for medical consultations. The application is designed with a mobile-first approach using modern web technologies.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React and TypeScript, utilizing Vite as the build tool and development server. The application follows a component-based architecture with:

- **Routing**: Wouter for lightweight client-side routing
- **State Management**: Zustand for authentication state with persistent storage
- **Data Fetching**: TanStack Query for server state management and caching
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom design system variables
- **Mobile-First Design**: Responsive layouts optimized for mobile devices

## Backend Architecture
The server is built with Express.js and TypeScript, featuring:

- **RESTful API**: Express routes for authentication, patient management, appointments, and queue operations
- **Data Layer**: In-memory storage implementation with interface abstraction for easy database migration
- **Authentication**: Role-based access control for secretaries and patients
- **Development Setup**: Hot reloading with Vite integration in development mode

## Database Schema Design
The system uses Drizzle ORM with PostgreSQL schema definitions including:

- **Users Table**: Authentication credentials and role management (secretary/patient)
- **Patients Table**: Patient demographic information linked to user accounts
- **Appointments Table**: Scheduled medical consultations with status tracking
- **Queue Entries Table**: Real-time waiting room management with position tracking

The schema supports referential integrity with foreign key relationships between entities.

## Key Features
- **Dual Authentication**: Separate login flows for medical staff and patients
- **Appointment Management**: Scheduling and status tracking for medical consultations
- **Queue System**: Real-time waiting room management with position tracking
- **Patient Registration**: Self-service patient account creation
- **Mobile Optimization**: Touch-friendly interface with tab navigation

# External Dependencies

## Core Framework Dependencies
- **React 18**: Frontend framework with hooks and modern patterns
- **Express.js**: Node.js web application framework for API server
- **TypeScript**: Type safety across both client and server code
- **Vite**: Build tool and development server with hot module replacement

## Database and ORM
- **Drizzle ORM**: Type-safe database toolkit with schema validation
- **Neon Database**: Serverless PostgreSQL database platform
- **Drizzle-Zod**: Schema validation integration

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless component primitives for accessibility
- **Shadcn/ui**: Pre-built component library with consistent design
- **Lucide React**: Icon library for user interface elements

## State Management and Data Fetching
- **TanStack Query**: Server state management with caching and synchronization
- **Zustand**: Lightweight state management for client-side state
- **React Hook Form**: Form handling with validation

## Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer
- **TSX**: TypeScript execution for development server

## Replit Integration
- **Replit Vite Plugins**: Development environment integration and error handling
- **Cartographer**: Code mapping and debugging tools for Replit environment