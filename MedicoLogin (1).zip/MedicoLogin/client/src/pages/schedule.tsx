import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/sidebar";
import AppointmentModal from "@/components/appointment-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar as CalendarIcon, 
  Plus, 
  ChevronLeft, 
  ChevronRight,
  Clock,
  User
} from "lucide-react";
import type { Appointment, Patient } from "@shared/schema";

interface CalendarDay {
  date: string;
  isCurrentMonth: boolean;
  isToday: boolean;
  appointments: Appointment[];
}

export default function Schedule() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: patients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
    retry: false,
  });

  const { data: appointments, isLoading: appointmentsLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments", currentDate.getFullYear(), currentDate.getMonth()],
    queryFn: async () => {
      const startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
      const endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];
      
      const response = await fetch(`/api/appointments?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error(`${response.status}: ${response.statusText}`);
      return response.json();
    },
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const generateCalendarDays = (): CalendarDay[] => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days: CalendarDay[] = [];
    const today = new Date().toISOString().split('T')[0];
    
    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      
      days.push({
        date: dateStr,
        isCurrentMonth: date.getMonth() === month,
        isToday: dateStr === today,
        appointments: appointments?.filter(apt => apt.date === dateStr) || [],
      });
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + (direction === 'next' ? 1 : -1));
      return newDate;
    });
  };

  const monthYear = currentDate.toLocaleDateString('pt-BR', { 
    month: 'long', 
    year: 'numeric' 
  });

  const calendarDays = generateCalendarDays();
  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  const getPatientName = (patientId: string) => {
    const patient = patients?.find(p => p.id === patientId);
    return patient ? `${patient.firstName} ${patient.lastName}` : 'Paciente não encontrado';
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 h-16 flex items-center justify-between px-6">
          <div>
            <h1 className="text-2xl font-semibold text-medical-dark">Agenda Mensal</h1>
            <p className="text-sm text-medical-gray">Visualize e gerencie todos os agendamentos</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              onClick={() => navigateMonth('prev')}
              size="sm"
            >
              <ChevronLeft size={16} />
            </Button>
            <span className="text-lg font-medium text-medical-dark min-w-[200px] text-center">
              {monthYear}
            </span>
            <Button 
              variant="outline" 
              onClick={() => navigateMonth('next')}
              size="sm"
            >
              <ChevronRight size={16} />
            </Button>
          </div>
        </header>

        <main className="p-6">
          {/* Calendar */}
          <Card className="shadow-sm border-gray-200">
            <CardContent className="p-6">
              {/* Week Headers */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {weekDays.map(day => (
                  <div key={day} className="text-center font-semibold text-medical-gray py-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {calendarDays.map((day, index) => (
                  <div
                    key={index}
                    className={`
                      min-h-[120px] border border-gray-200 rounded-lg p-2 cursor-pointer
                      transition-colors hover:bg-blue-50
                      ${day.isCurrentMonth ? 'bg-white' : 'bg-gray-50'}
                      ${day.isToday ? 'ring-2 ring-medical-blue bg-blue-50' : ''}
                      ${selectedDate === day.date ? 'ring-2 ring-medical-green' : ''}
                    `}
                    onClick={() => setSelectedDate(day.date)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className={`
                        text-sm font-medium
                        ${day.isCurrentMonth ? 'text-medical-dark' : 'text-medical-gray'}
                        ${day.isToday ? 'text-medical-blue font-bold' : ''}
                      `}>
                        {new Date(day.date).getDate()}
                      </span>
                      {day.appointments.length > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {day.appointments.length}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      {day.appointments.slice(0, 3).map((appointment) => (
                        <div
                          key={appointment.id}
                          className={`
                            text-xs p-1 rounded text-white truncate
                            ${appointment.status === 'scheduled' ? 'bg-medical-blue' :
                              appointment.status === 'completed' ? 'bg-medical-green' :
                              appointment.status === 'cancelled' ? 'bg-medical-red' :
                              'bg-medical-gray'}
                          `}
                        >
                          <div className="flex items-center space-x-1">
                            <Clock size={10} />
                            <span>{appointment.time}</span>
                          </div>
                          <div className="truncate">
                            {getPatientName(appointment.patientId)}
                          </div>
                        </div>
                      ))}
                      {day.appointments.length > 3 && (
                        <div className="text-xs text-medical-gray">
                          +{day.appointments.length - 3} mais
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Selected Date Details */}
          {selectedDate && (
            <Card className="shadow-sm border-gray-200 mt-6">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-medical-dark">
                    Agendamentos para {new Date(selectedDate).toLocaleDateString('pt-BR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </h3>
                  <Button 
                    className="bg-medical-blue hover:bg-blue-700 text-white"
                    onClick={() => setShowAppointmentModal(true)}
                  >
                    <Plus className="mr-2" size={16} />
                    Novo Agendamento
                  </Button>
                </div>

                <div className="space-y-3">
                  {calendarDays
                    .find(day => day.date === selectedDate)
                    ?.appointments
                    .sort((a, b) => a.time.localeCompare(b.time))
                    .map((appointment) => (
                    <div
                      key={appointment.id}
                      className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Clock className="text-medical-blue" size={16} />
                          <span className="font-medium text-medical-dark">
                            {appointment.time}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <User className="text-medical-gray" size={16} />
                          <span className="text-medical-dark">
                            {getPatientName(appointment.patientId)}
                          </span>
                        </div>
                        <Badge className={`
                          ${appointment.status === 'scheduled' ? 'bg-blue-100 text-medical-blue' :
                            appointment.status === 'completed' ? 'bg-green-100 text-medical-green' :
                            appointment.status === 'cancelled' ? 'bg-red-100 text-medical-red' :
                            'bg-gray-100 text-medical-gray'}
                        `}>
                          {appointment.status === 'scheduled' ? 'Agendado' :
                           appointment.status === 'completed' ? 'Concluído' :
                           appointment.status === 'cancelled' ? 'Cancelado' : 
                           appointment.status}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          Editar
                        </Button>
                        <Button variant="ghost" size="sm" className="text-medical-red">
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  )) || (
                    <div className="text-center py-8 text-medical-gray">
                      <CalendarIcon size={48} className="mx-auto mb-4 opacity-50" />
                      <p>Nenhum agendamento para esta data</p>
                      <p className="text-sm">Clique em "Novo Agendamento" para adicionar</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
      
      <AppointmentModal
        isOpen={showAppointmentModal}
        onClose={() => setShowAppointmentModal(false)}
        selectedDate={selectedDate || undefined}
      />
    </div>
  );
}