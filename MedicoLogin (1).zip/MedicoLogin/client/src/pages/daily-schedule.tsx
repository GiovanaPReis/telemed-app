import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/sidebar";
import AppointmentModal from "@/components/appointment-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  CalendarDays, 
  Plus, 
  Clock,
  User,
  Phone,
  AlertCircle,
  CheckCircle,
  UserX,
  Play
} from "lucide-react";
import type { Appointment, Patient } from "@shared/schema";

export default function DailySchedule() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Get today's date in YYYY-MM-DD format
  const today = new Date().toISOString().split('T')[0];

  // Fetch today's appointments
  const { data: appointments = [], isLoading: appointmentsLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments/today"],
    retry: false,
  });

  // Fetch patients for appointment details
  const { data: patients = [] } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
    retry: false,
  });

  // Create a map of patient ID to patient data for quick lookup
  const patientsMap = patients.reduce((acc, patient) => {
    acc[patient.id] = patient;
    return acc;
  }, {} as Record<string, Patient>);

  // Update appointment status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ appointmentId, status }: { appointmentId: string; status: string }) => {
      await apiRequest('PATCH', `/api/appointments/${appointmentId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Sucesso",
        description: "Status da consulta atualizado",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao atualizar status da consulta",
        variant: "destructive",
      });
    },
  });

  const handleStatusUpdate = (appointmentId: string, status: string) => {
    updateStatusMutation.mutate({ appointmentId, status });
  };

  // Sort appointments by time
  const sortedAppointments = appointments
    .sort((a, b) => a.time.localeCompare(b.time));

  // Get status badge variant and label
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return { variant: 'default' as const, label: 'Agendado', icon: Clock };
      case 'in_progress':
        return { variant: 'secondary' as const, label: 'Em Andamento', icon: Play };
      case 'completed':
        return { variant: 'success' as const, label: 'Concluído', icon: CheckCircle };
      case 'no_show':
        return { variant: 'destructive' as const, label: 'Faltou', icon: UserX };
      case 'cancelled':
        return { variant: 'outline' as const, label: 'Cancelado', icon: AlertCircle };
      default:
        return { variant: 'default' as const, label: status, icon: Clock };
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-medical-blue"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8 ml-64">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <CalendarDays className="text-medical-blue" size={32} />
                <div>
                  <h1 className="text-3xl font-bold text-medical-dark">Agenda Diária</h1>
                  <p className="text-gray-600">
                    {new Date().toLocaleDateString('pt-BR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              </div>
              <Button 
                className="bg-medical-blue hover:bg-blue-700 text-white"
                onClick={() => setShowAppointmentModal(true)}
              >
                <Plus className="mr-2" size={16} />
                Novo Agendamento
              </Button>
            </div>

            {/* Daily Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="text-medical-blue" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Total de Hoje</p>
                      <p className="text-2xl font-bold text-medical-dark">{appointments.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Play className="text-yellow-600" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Em Andamento</p>
                      <p className="text-2xl font-bold text-yellow-600">
                        {appointments.filter(apt => apt.status === 'in_progress').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="text-medical-green" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Concluídos</p>
                      <p className="text-2xl font-bold text-medical-green">
                        {appointments.filter(apt => apt.status === 'completed').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <UserX className="text-medical-red" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Faltas</p>
                      <p className="text-2xl font-bold text-medical-red">
                        {appointments.filter(apt => apt.status === 'no_show').length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Appointments List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CalendarDays className="text-medical-blue" size={20} />
                  <span>Agendamentos de Hoje</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {appointmentsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-medical-blue"></div>
                  </div>
                ) : sortedAppointments.length === 0 ? (
                  <div className="text-center py-8">
                    <CalendarDays className="mx-auto text-gray-400 mb-4" size={48} />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum agendamento hoje</h3>
                    <p className="text-gray-600 mb-4">Não há consultas agendadas para hoje.</p>
                    <Button 
                      className="bg-medical-blue hover:bg-blue-700 text-white"
                      onClick={() => setShowAppointmentModal(true)}
                    >
                      <Plus className="mr-2" size={16} />
                      Agendar Consulta
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {sortedAppointments.map((appointment) => {
                      const patient = patientsMap[appointment.patientId];
                      const statusBadge = getStatusBadge(appointment.status);
                      const StatusIcon = statusBadge.icon;

                      return (
                        <div 
                          key={appointment.id} 
                          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center space-x-4">
                            <div className="text-center min-w-[60px]">
                              <p className="text-lg font-bold text-medical-blue">{appointment.time}</p>
                              <p className="text-xs text-gray-600">{appointment.duration}min</p>
                            </div>
                            
                            <div className="border-l border-gray-300 h-12"></div>
                            
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <User size={16} className="text-gray-600" />
                                <h3 className="font-semibold text-medical-dark">
                                  {patient ? `${patient.firstName} ${patient.lastName}` : 'Paciente não encontrado'}
                                </h3>
                              </div>
                              
                              {patient && (
                                <div className="flex items-center space-x-4 text-sm text-gray-600">
                                  <div className="flex items-center space-x-1">
                                    <Phone size={14} />
                                    <span>{patient.phone}</span>
                                  </div>
                                  {appointment.notes && (
                                    <div className="flex items-center space-x-1">
                                      <AlertCircle size={14} />
                                      <span className="truncate max-w-[200px]">{appointment.notes}</span>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center space-x-3">
                            <Badge variant={statusBadge.variant} className="flex items-center space-x-1">
                              <StatusIcon size={12} />
                              <span>{statusBadge.label}</span>
                            </Badge>

                            {appointment.status === 'scheduled' && (
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  className="bg-medical-green hover:bg-green-700 text-white"
                                  onClick={() => handleStatusUpdate(appointment.id, 'in_progress')}
                                  disabled={updateStatusMutation.isPending}
                                >
                                  <Play size={14} className="mr-1" />
                                  Iniciar
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-medical-red border-medical-red hover:bg-red-50"
                                  onClick={() => handleStatusUpdate(appointment.id, 'no_show')}
                                  disabled={updateStatusMutation.isPending}
                                >
                                  <UserX size={14} className="mr-1" />
                                  Faltou
                                </Button>
                              </div>
                            )}

                            {appointment.status === 'in_progress' && (
                              <Button
                                size="sm"
                                className="bg-medical-blue hover:bg-blue-700 text-white"
                                onClick={() => handleStatusUpdate(appointment.id, 'completed')}
                                disabled={updateStatusMutation.isPending}
                              >
                                <CheckCircle size={14} className="mr-1" />
                                Finalizar
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      <AppointmentModal
        isOpen={showAppointmentModal}
        onClose={() => setShowAppointmentModal(false)}
        selectedDate={today}
      />
    </div>
  );
}