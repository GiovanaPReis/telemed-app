import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Plus, 
  Eye, 
  Edit, 
  Trash2, 
  Download,
  Users,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Link } from "wouter";
import type { Patient } from "@shared/schema";

export default function Patients() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: patients, isLoading: patientsLoading } = useQuery<Patient[]>({
    queryKey: ["/api/patients", searchQuery, statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append('search', searchQuery);
      if (statusFilter) params.append('status', statusFilter);
      
      const response = await fetch(`/api/patients?${params}`);
      if (!response.ok) throw new Error(`${response.status}: ${response.statusText}`);
      return response.json();
    },
    retry: false,
  });

  const deleteMutation = useMutation({
    mutationFn: async (patientId: string) => {
      await apiRequest('DELETE', `/api/patients/${patientId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/patients"] });
      toast({
        title: "Success",
        description: "Patient deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete patient",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const handleDelete = (patientId: string) => {
    if (confirm("Are you sure you want to delete this patient? This action cannot be undone.")) {
      deleteMutation.mutate(patientId);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-medical-green border-green-200">Active</Badge>;
      case 'pending':
        return <Badge className="bg-blue-100 text-medical-blue border-blue-200">Pending</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-medical-gray border-gray-200">Inactive</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 h-16 flex items-center justify-between px-6">
          <div>
            <h1 className="text-2xl font-semibold text-medical-dark">Patient Management</h1>
            <p className="text-sm text-medical-gray">View and manage all registered patients</p>
          </div>
          <Link href="/add-patient">
            <Button className="bg-medical-blue hover:bg-blue-700 text-white">
              <Plus className="mr-2" size={16} />
              Add Patient
            </Button>
          </Link>
        </header>

        <main className="p-6">
          {/* Search and Filter Bar */}
          <Card className="shadow-sm border-gray-200 mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
                <div className="flex-1 relative max-w-md">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="text-medical-gray" size={16} />
                  </div>
                  <Input
                    type="text"
                    className="pl-10"
                    placeholder="Search patients by name, email, or phone..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <div className="flex items-center space-x-4">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="All Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button variant="outline">
                    <Download className="mr-2" size={16} />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Patient Table */}
          <Card className="shadow-sm border-gray-200">
            <div className="overflow-x-auto">
              {patientsLoading ? (
                <div className="p-8 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-medical-blue mx-auto"></div>
                  <p className="mt-2 text-medical-gray">Loading patients...</p>
                </div>
              ) : patients && patients.length > 0 ? (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-medical-gray uppercase tracking-wider">
                        Patient
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-medical-gray uppercase tracking-wider">
                        Contact
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-medical-gray uppercase tracking-wider">
                        Registration Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-medical-gray uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-medical-gray uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {patients.map((patient) => (
                      <tr key={patient.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-10 w-10 bg-medical-blue rounded-full flex items-center justify-center">
                              <span className="text-white font-medium text-sm">
                                {patient.firstName[0]}{patient.lastName[0]}
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-medical-dark">
                                {patient.firstName} {patient.lastName}
                              </div>
                              <div className="text-sm text-medical-gray">
                                DOB: {new Date(patient.dateOfBirth).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-medical-dark">{patient.email}</div>
                          <div className="text-sm text-medical-gray">{patient.phone}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-medical-dark">
                            {new Date(patient.createdAt!).toLocaleDateString()}
                          </div>
                          <div className="text-sm text-medical-gray">
                            {patient.city}, {patient.zipCode}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(patient.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <Button variant="ghost" size="sm" className="text-medical-blue hover:text-blue-700">
                              <Eye size={16} />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-medical-gray hover:text-medical-dark">
                              <Edit size={16} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-medical-red hover:text-red-700"
                              onClick={() => handleDelete(patient.id)}
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 size={16} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-12">
                  <Users size={64} className="mx-auto mb-4 text-medical-gray opacity-50" />
                  <h3 className="text-lg font-medium text-medical-dark mb-2">No patients found</h3>
                  <p className="text-medical-gray mb-4">
                    {searchQuery || statusFilter 
                      ? "Try adjusting your search criteria" 
                      : "Get started by adding your first patient"}
                  </p>
                  <Link href="/add-patient">
                    <Button className="bg-medical-blue hover:bg-blue-700 text-white">
                      <Plus className="mr-2" size={16} />
                      Add First Patient
                    </Button>
                  </Link>
                </div>
              )}
            </div>
            
            {/* Pagination placeholder */}
            {patients && patients.length > 0 && (
              <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                <div className="flex-1 flex justify-between sm:hidden">
                  <Button variant="outline" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" disabled>
                    Next
                  </Button>
                </div>
                <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm text-medical-gray">
                      Showing <span className="font-medium">1</span> to{" "}
                      <span className="font-medium">{patients.length}</span> of{" "}
                      <span className="font-medium">{patients.length}</span> results
                    </p>
                  </div>
                  <div>
                    <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                      <Button variant="outline" size="sm" disabled>
                        <ChevronLeft size={16} />
                      </Button>
                      <Button variant="outline" size="sm" className="bg-medical-blue text-white">
                        1
                      </Button>
                      <Button variant="outline" size="sm" disabled>
                        <ChevronRight size={16} />
                      </Button>
                    </nav>
                  </div>
                </div>
              </div>
            )}
          </Card>
        </main>
      </div>
    </div>
  );
}
