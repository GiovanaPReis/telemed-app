import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserCheck, Shield, Lock } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-slate-100 px-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-medical-blue rounded-full flex items-center justify-center mb-4">
            <UserCheck className="text-white text-2xl" size={32} />
          </div>
          <h2 className="text-3xl font-bold text-medical-dark">MedPatient Pro</h2>
          <p className="mt-2 text-medical-gray">Secure Patient Management System</p>
        </div>
        
        <Card className="shadow-lg border-0">
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center space-x-2 text-medical-gray">
                  <Shield size={16} />
                  <span className="text-sm">HIPAA Compliant</span>
                </div>
                <p className="text-sm text-medical-gray">
                  Access your secure medical practice management system to manage patient records, 
                  appointments, and medical data with enterprise-grade security.
                </p>
              </div>

              <Button 
                onClick={handleLogin}
                className="w-full bg-medical-blue hover:bg-blue-700 text-white py-3"
                size="lg"
              >
                <Lock className="mr-2" size={16} />
                Sign In Securely
              </Button>

              <div className="text-center">
                <p className="text-xs text-medical-gray">
                  Authorized personnel only. All access is monitored and logged.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
