import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Users, 
  UserCheck, 
  Calendar, 
  ClipboardList,
  UserPlus,
  CalendarPlus,
  FileText,
  Search,
  Bell
} from "lucide-react";
import { Link, useLocation } from "wouter";
import type { Patient } from "@shared/schema";

interface Stats {
  totalPatients: number;
  activeToday: number;
  appointments: number;
  pendingReviews: number;
}

export default function Home() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
    retry: false,
  });

  const { data: recentPatients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const currentDate = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const userInitials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}`.toUpperCase()
    : user?.email?.[0]?.toUpperCase() || 'U';

  const userName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}`
    : user?.email || 'User';

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        {/* Top Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 h-16 flex items-center justify-between px-6">
          <div>
            <h1 className="text-2xl font-semibold text-medical-dark">Dashboard</h1>
            <p className="text-sm text-medical-gray">Welcome back, manage your patients efficiently</p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-medical-gray hover:text-medical-dark transition-colors">
              <Bell size={20} />
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-medical-red"></span>
            </button>
            <div className="text-sm text-medical-gray">
              {currentDate}
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-medical-gray">Total Patients</p>
                    <p className="text-3xl font-bold text-medical-dark">
                      {statsLoading ? '...' : stats?.totalPatients || 0}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="text-medical-blue" size={24} />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-medical-green font-medium">Active System</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-medical-gray">Active Patients</p>
                    <p className="text-3xl font-bold text-medical-dark">
                      {statsLoading ? '...' : stats?.activeToday || 0}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <UserCheck className="text-medical-green" size={24} />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-medical-gray">Current status</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-medical-gray">Appointments</p>
                    <p className="text-3xl font-bold text-medical-dark">
                      {statsLoading ? '...' : stats?.appointments || 0}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Calendar className="text-purple-600" size={24} />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-medical-gray">Scheduled for today</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-medical-gray">Pending Reviews</p>
                    <p className="text-3xl font-bold text-medical-dark">
                      {statsLoading ? '...' : stats?.pendingReviews || 0}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <ClipboardList className="text-yellow-600" size={24} />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-medical-red font-medium">Needs attention</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Patients & Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Patients */}
            <div className="lg:col-span-2">
              <Card className="shadow-sm border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-medical-dark">Recent Patients</h3>
                    <Link href="/patients">
                      <Button variant="ghost" className="text-medical-blue hover:text-blue-700">
                        View All
                      </Button>
                    </Link>
                  </div>
                </div>
                <CardContent className="p-6">
                  {recentPatients && recentPatients.length > 0 ? (
                    <div className="space-y-4">
                      {recentPatients.slice(0, 3).map((patient: any) => (
                        <div key={patient.id} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-center space-x-4">
                            <div className="h-10 w-10 bg-medical-blue rounded-full flex items-center justify-center">
                              <span className="text-white font-medium text-sm">
                                {patient.firstName[0]}{patient.lastName[0]}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-medical-dark">
                                {patient.firstName} {patient.lastName}
                              </p>
                              <p className="text-sm text-medical-gray">{patient.email}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-medical-dark">
                              {new Date(patient.createdAt).toLocaleDateString()}
                            </p>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              patient.status === 'active' ? 'bg-green-100 text-medical-green' :
                              patient.status === 'pending' ? 'bg-blue-100 text-medical-blue' :
                              'bg-gray-100 text-medical-gray'
                            }`}>
                              {patient.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-medical-gray">
                      <Users size={48} className="mx-auto mb-4 opacity-50" />
                      <p>No patients registered yet</p>
                      <p className="text-sm">Add your first patient to get started</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div>
              <Card className="shadow-sm border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-medical-dark">Quick Actions</h3>
                </div>
                <CardContent className="p-6 space-y-4">
                  <Link href="/add-patient">
                    <Button className="w-full bg-medical-blue hover:bg-blue-700 text-white">
                      <UserPlus className="mr-2" size={16} />
                      Add New Patient
                    </Button>
                  </Link>
                  
                  <Link href="/schedule">
                    <Button variant="outline" className="w-full">
                      <Calendar className="mr-2" size={16} />
                      Monthly Schedule
                    </Button>
                  </Link>
                  
                  <Link href="/daily-schedule">
                    <Button variant="outline" className="w-full">
                      <CalendarPlus className="mr-2" size={16} />
                      Daily Agenda
                    </Button>
                  </Link>
                  
                  <Button variant="outline" className="w-full">
                    <FileText className="mr-2" size={16} />
                    Generate Report
                  </Button>
                  
                  <Link href="/patients">
                    <Button variant="outline" className="w-full">
                      <Search className="mr-2" size={16} />
                      Search Patients
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
