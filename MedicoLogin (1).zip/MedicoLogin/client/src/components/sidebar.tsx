import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { 
  BarChart3, 
  Users, 
  UserPlus, 
  Calendar, 
  CalendarDays,
  FileText, 
  UserCheck,
  LogOut
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const userInitials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}`.toUpperCase()
    : user?.email?.[0]?.toUpperCase() || 'U';

  const userName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}`
    : user?.email || 'User';

  const navItems = [
    { href: "/", label: "Dashboard", icon: BarChart3 },
    { href: "/patients", label: "Pacientes", icon: Users },
    { href: "/add-patient", label: "Novo Paciente", icon: UserPlus },
    { href: "/schedule", label: "Agenda Mensal", icon: Calendar },
    { href: "/daily-schedule", label: "Agenda Diária", icon: CalendarDays },
    { href: "/reports", label: "Relatórios", icon: FileText },
  ];

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg border-r border-gray-200">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-medical-blue rounded-lg flex items-center justify-center">
              <UserCheck className="text-white" size={16} />
            </div>
            <span className="text-lg font-semibold text-medical-dark">MedPatient Pro</span>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-4 py-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || 
              (item.href !== "/" && location.startsWith(item.href));
            
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={`w-full justify-start ${
                    isActive
                      ? "bg-blue-50 text-medical-blue border-r-2 border-medical-blue"
                      : "text-medical-gray hover:bg-gray-50 hover:text-medical-dark"
                  }`}
                >
                  <Icon className="mr-3" size={16} />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>

        {/* User Profile */}
        <div className="px-4 py-4 border-t border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 bg-medical-blue rounded-full flex items-center justify-center">
              <span className="text-white font-medium text-sm">{userInitials}</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-medical-dark">{userName}</p>
              <p className="text-xs text-medical-gray">Administrator</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-medical-gray hover:text-medical-dark"
            >
              <LogOut size={16} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
