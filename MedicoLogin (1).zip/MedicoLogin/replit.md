# MedPatient Pro - Medical Practice Management System

## Overview

MedPatient Pro is a secure, HIPAA-compliant medical practice management system designed for healthcare providers to manage patient records, appointments, and medical data. The application features a modern React frontend with a Node.js/Express backend, utilizing PostgreSQL for data persistence and Replit's OAuth system for authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Library**: Radix UI components with shadcn/ui styling system for accessible, professional medical interface
- **Styling**: Tailwind CSS with custom medical theme variables (medical-blue, medical-green, medical-red, medical-gray, medical-dark)
- **State Management**: TanStack Query (React Query) for server state management with optimistic updates
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules for type safety and modern JavaScript features
- **API Design**: RESTful API with clear separation between authentication and business logic routes
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **Request Logging**: Custom middleware for API request/response logging with duration tracking

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations with PostgreSQL
- **Database**: PostgreSQL with Neon serverless connection pooling
- **Migrations**: Drizzle Kit for schema migrations and database management
- **Schema Design**: Normalized tables for users, patients, and sessions with proper relationships

### Authentication & Authorization
- **Provider**: Replit's OAuth system with OpenID Connect (OIDC)
- **Session Management**: Express session with PostgreSQL session store using connect-pg-simple
- **Security**: HTTP-only cookies, secure session configuration, and CSRF protection
- **User Management**: Automatic user creation/update on login with profile data sync

### Data Validation
- **Runtime Validation**: Zod schemas for both client and server-side validation
- **Type Safety**: Shared TypeScript types between frontend and backend via shared schema
- **Form Validation**: React Hook Form integration with Zod resolvers for real-time validation

## External Dependencies

### Core Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Replit Authentication**: OAuth provider for secure user authentication
- **Replit Infrastructure**: Development and deployment platform

### Frontend Libraries
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **UI Components**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Icons**: Lucide React for consistent medical iconography
- **Date Handling**: date-fns for date formatting and manipulation

### Backend Libraries
- **Database**: Drizzle ORM, @neondatabase/serverless, connect-pg-simple
- **Authentication**: openid-client, passport for OAuth integration
- **Utilities**: memoizee for caching, ws for WebSocket support

### Development Tools
- **Build System**: Vite with React plugin and TypeScript support
- **Code Quality**: TypeScript compiler, ESBuild for production builds
- **Development**: Replit-specific plugins for error overlay and development tools